////
//  KualiteeSDK.h
//  KualiteeSDK
//
//  Created by CodeX on 13/03/2019
//  Copyright © 2018 Dev_iOS. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KualiteeSDK.
FOUNDATION_EXPORT double KualiteeSDKVersionNumber;

//! Project version string for KualiteeSDK.
FOUNDATION_EXPORT const unsigned char KualiteeSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KualiteeSDK/PublicHeader.h>


